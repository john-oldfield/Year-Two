package com.example.joldf_000.pointsofinterest;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.ItemizedIconOverlay;
import org.osmdroid.views.overlay.OverlayItem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends Activity// implements LocationListener
{
    MapView mv;
    String curLat;
    String curLon;
    ItemizedIconOverlay<OverlayItem> items;
    ItemizedIconOverlay.OnItemGestureListener<OverlayItem> markerGestureListener;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Init the SharedData class.
        SharedData.places = new ArrayList<Place>();

        //Get the map fragment
        MapFrag mapFrag = (MapFrag) getFragmentManager().findFragmentById(R.id.mapFrag);

        //Set initial map view
        mv = (MapView) mapFrag.getView().findViewById(R.id.themap);
        mv.setBuiltInZoomControls(true);
        mv.getController().setCenter(new GeoPoint(52.8140 , -1.6371));
        mv.getController().setZoom(13);

        /*
            ----- CODE FOR GETTING LOCATION WHEN ON ACTUAL DEVICE -----
            LocationManager mgr = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission
                    (this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            {
                return;
            }
            mgr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        */

        //Makes markers display text when pressed
        markerGestureListener = new ItemizedIconOverlay.OnItemGestureListener<OverlayItem>()
        {
            public boolean onItemLongPress(int i, OverlayItem item)
            {
                Toast.makeText(MainActivity.this, item.getSnippet(), Toast.LENGTH_SHORT).show();
                return true;
            }

            public boolean onItemSingleTapUp(int i, OverlayItem item)
            {
                Toast.makeText(MainActivity.this, item.getSnippet(), Toast.LENGTH_SHORT).show();
                return true;
            }
        };

        items = new ItemizedIconOverlay<OverlayItem>(this, new ArrayList<OverlayItem>(), markerGestureListener);

        mv.getOverlays().add(items);

        // load pois from web
        LoadWeb lw = new LoadWeb();
        lw.execute();

        //Toast.makeText(this,String.valueOf(SharedData.places.size()),Toast.LENGTH_LONG).show();
    }

    public void onLocationChanged(Location newLoc)
    {
        //When location changes move the map relatively
        mv.getController().setCenter(new GeoPoint(newLoc.getLatitude() , newLoc.getLongitude()));
        curLat = Double.toString(newLoc.getLatitude());
        curLon = Double.toString(newLoc.getLongitude());
    }

    public void onProviderDisabled(String provider)
    {
        //Display message if provider disabled
        Toast.makeText(this, "Provider " + provider +
                " disabled", Toast.LENGTH_LONG).show();
    }

    public void onProviderEnabled(String provider)
    {
        //Display message if provider enabled
        Toast.makeText(this, "Provider " + provider +
                " enabled", Toast.LENGTH_LONG).show();
    }

    public void onStatusChanged(String provider,int status,Bundle extras)
    {
        //If status changes display message
        Toast.makeText(this, "Status changed: " + status,
                Toast.LENGTH_SHORT).show();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        //Inflate menu
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        if(item.getItemId() == R.id.map)
        {
            // react to the menu item being selected...
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.addPOI)
        {
            // react to the menu item being selected...
            Intent intent = new Intent(this,AddPOI.class);
            Bundle coords = new Bundle();

            //Put lat and lon in bundle to be displayed on add activity
            coords.putString("curLat", curLat);
            coords.putString("curLon", curLon);

            intent.putExtras(coords);
            startActivityForResult(intent,0);

            return true;
        }

        if(item.getItemId() == R.id.saveFile)
        {
            //call save poi method
            savePOIs();
        }

        if(item.getItemId() == R.id.loadFile)
        {
            try
            {
                //Load file from SD card on phone
                BufferedReader reader = new BufferedReader(new FileReader(Environment.getExternalStorageDirectory().getAbsolutePath() + "/places.csv"));
                String line;

                while((line = reader.readLine()) != null)
                {
                    //Split the csv
                    String[] components = line.split(",");
                    if(components.length==5)
                    {
                        //Assign values from file to variables
                        String name = components[0];
                        String type = components[1];
                        String desc = components[2];
                        Double lat = Double.valueOf(components[3]);
                        Double lon = Double.valueOf(components[4]);

                        //Add place to SharedData class
                        SharedData.places.add(new Place(name, type, desc, lat, lon));

                        //Add to map as markers
                        OverlayItem newItem = new OverlayItem(name, desc, new GeoPoint(lat, lon));
                        items.addItem(newItem);
                    }
                }
            }
            catch(IOException e)
            {
                System.out.println("I/O Error: " + e);
            }
            Toast.makeText(this, "File Loaded", Toast.LENGTH_LONG).show();
        }
        /*if(item.getItemId() == R.id.saveWeb)
        {
            // react to the menu item being selected...

            Toast.makeText(this, "Uploaded", Toast.LENGTH_LONG).show();
        }No longer needed as saving happens when adding POI if preference set*/
        if(item.getItemId() == R.id.loadWeb)
        {
            // react to the menu item being selected...
            Toast.makeText(this, "Downloaded", Toast.LENGTH_LONG).show();
            //Execute load web asynctask
            LoadWeb lw = new LoadWeb();
            lw.execute();
        }
        /*if(item.getItemId() == R.id.listPOI)
        {
            // react to the menu item being selected...
            Intent intent = new Intent(this,ListPOI.class);
            startActivity(intent);
            return true;
        } --- NOT NEEDED WHILST DOING QUESTION 8 --- */
        if(item.getItemId() == R.id.preferences)
        {
            // react to the menu item being selected...
            Intent intent = new Intent(this,Preferences.class);
            startActivity(intent);
            return true;
        }
        return false;
    }

    protected void onActivityResult(int requestCode,int resultCode,Intent intent)
    {
        if(requestCode==0)
        {
            if (resultCode==RESULT_OK)
            {
                //get newly added poi info from previous activity
                Bundle extras = intent.getExtras();
                String poiName = extras.getString("poiName");
                String poiDesc = extras.getString("poiDesc");
                String poiType = extras.getString("poiType");
                Double lat = extras.getDouble("latitude");
                Double lon = extras.getDouble("longitude");

                //Add new poi to sharedata
                SharedData.places.add(new Place(poiName, poiType, poiDesc, lat, lon));

                //Add new poi to map as overlay item
                items = new ItemizedIconOverlay<OverlayItem>(this, new ArrayList<OverlayItem>(), markerGestureListener);
                OverlayItem newItem = new OverlayItem(poiName, poiDesc, new GeoPoint(lat, lon));
                items.addItem(newItem);
                mv.getOverlays().add(items);

                Toast.makeText(this, poiName + " Added", Toast.LENGTH_LONG).show();

                //See if preference  to upload to web is checked and act accordingly
                //REQUIREMENT 7 IS HERE
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                boolean autoupload = prefs.getBoolean("uploadWeb", false);
                if(autoupload == true)
                {
                    String lati = lat.toString();
                    String loni = lon.toString();
                    //Execute save web asynctask
                    saveWeb sw = new saveWeb();
                    sw.execute(poiName, poiType, poiDesc, lati, loni);
                }
                else
                {
                    new AlertDialog.Builder(MainActivity.this).setMessage("Did you know? POI can be automatically " +
                            "uploaded to the web! You can choose this setting in the preferences menu.").setPositiveButton("OK", null).show();
                }
            }
        }
    }

    public void onStart()
    {
        super.onStart();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        boolean autoupload = prefs.getBoolean("uploadWeb", false);

        //Requirement 4 is here
        if(autoupload == true)
        {
            Toast.makeText(this, "Auto-Upload Enabled", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(this, " Auto-Upload Disabled", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onStop()
    {
        super.onStop();
        //REQUIREMENT 3 - saves poi when app closed
        savePOIs();
    }

    private void savePOIs()
    {
        try
        {
            PrintWriter pw =
                    new PrintWriter( new FileWriter(Environment.getExternalStorageDirectory().getAbsolutePath() + "/places.csv"));

            for(int i = 0; i < SharedData.places.size(); i++)
            {
                //Save all shareddata as csv
                String name = SharedData.places.get(i).getName();
                String type = SharedData.places.get(i).getType();
                String desc = SharedData.places.get(i).getDesc();
                String lat = SharedData.places.get(i).getLat().toString();
                String lon = SharedData.places.get(i).getLon().toString();

                pw.write(name + "," + type + "," + desc + "," + lat + "," + lon + "\n");
            }

            pw.close(); // close the file to ensure data is flushed to file
        }
        catch(IOException e)
        {
            System.out.println ("I/O Error: " + e);
        }

        Toast.makeText(this, "File Saved", Toast.LENGTH_SHORT).show();
    }

    class LoadWeb extends AsyncTask<Void,Void,String>
    {
        public String doInBackground(Void... unused)
        {
            HttpURLConnection conn = null;
            try
            {
                //Connect to webservice
                URL url = new URL("http://www.free-map.org.uk/course/mad/ws/get.php?year=17&username=user001&format=json");
                conn = (HttpURLConnection) url.openConnection();
                if(conn.getResponseCode() == 200)
                {
                    //return result from web service
                    InputStream in = conn.getInputStream();
                    BufferedReader b = new BufferedReader(new InputStreamReader(in));
                    String result = "", line;
                    while((line = b.readLine()) != null)
                    {
                        result += line;
                    }
                    return result;
                }
                else
                {
                    return "HTTP ERROR: " + conn.getResponseCode();
                }
            }
            catch(IOException e)
            {
               return e.toString();
            }
            finally
            {
                if(conn!=null)
                {
                    conn.disconnect();
                }
            }
        }

        public void onPostExecute(String result)
        {
            try
            {
                JSONArray jsonArr = new JSONArray(result);

                for(int i=0; i<jsonArr.length(); i++)
                {
                    //Add places to shared data
                    JSONObject curObj = jsonArr.getJSONObject(i);
                    String name = curObj.getString("name");
                    String type = curObj.getString("type");
                    String desc = curObj.getString("description");
                    Double lat = curObj.getDouble("lat");
                    Double lon = curObj.getDouble("lon");

                    SharedData.places.add(new Place(name, type, desc, lat, lon));

                    items = new ItemizedIconOverlay<OverlayItem>(MainActivity.this, new ArrayList<OverlayItem>(), markerGestureListener);
                    OverlayItem newItem = new OverlayItem(name, desc, new GeoPoint(lat, lon));
                    items.addItem(newItem);
                    mv.getOverlays().add(items);
                }
            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
        }
    }

    //Save poi to the web when added
    class saveWeb extends AsyncTask<String, Void, String>
    {
        @Override
        public String doInBackground(String... args)
        {
            HttpURLConnection conn = null;
            try
            {
                //Connect to webservice
                URL url = new URL("http://www.free-map.org.uk/course/mad/ws/add.php");
                conn = (HttpURLConnection) url.openConnection();

                String poiName = args[0];
                String poiType = args[1];
                String poiDesc = args[2];
                String lat = args[3];
                String lon = args[4];

                String postData = "username=user001&name=" + poiName + "&type=" + poiType + "&description="
                        + poiDesc + "&lat=" + lat + "&lon=" + lon + "&year=17";
                //For POST
                conn.setDoOutput(true);
                conn.setFixedLengthStreamingMode(postData.length());

                OutputStream out = null;
                out = conn.getOutputStream();
                out.write(postData.getBytes());

                if(conn.getResponseCode() == 200)
                {
                    InputStream in = conn.getInputStream();
                    BufferedReader b = new BufferedReader(new InputStreamReader(in));
                    String result = "", line;
                    while((line = b.readLine()) != null)
                    {
                        result += line;
                    }
                    return result;
                }
                else
                {
                    return "HTTP ERROR: " + conn.getResponseCode();
                }
            }
            catch(IOException e)
            {
                return e.toString();
            }
            finally
            {
                if(conn!=null)
                {
                    conn.disconnect();
                }
            }
        }
        public void onPostExecute(String result)
        {
            //Display message from server
            new AlertDialog.Builder(MainActivity.this).setMessage("Server Sent Back: " + result).setPositiveButton("OK", null).show();
        }
    }
}
