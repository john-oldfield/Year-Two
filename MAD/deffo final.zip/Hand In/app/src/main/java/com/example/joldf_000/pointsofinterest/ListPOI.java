package com.example.joldf_000.pointsofinterest;

import android.app.ListFragment;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

public class ListPOI extends ListFragment
{
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);

        /*
            //Create Arrarys to display list item titles and details
            String[] names = new String [SharedData.places.size()],
                 details = new String[SharedData.places.size()];
        */

          //For loop to loop through place arrays and add to list item arrays
//        for(int i=0; i<SharedData.places.size(); i++)
//        {
//            Toast.makeText(getActivity(), "Testing...", Toast.LENGTH_LONG).show();
//            names[i] = SharedData.places.get(i).getName();
//            details[i] = SharedData.places.get(i).getType();
//        }
//
          // Set titles on list items
//        ArrayAdapter<String> adapter = new ArrayAdapter<String> (this.getActivity(),  android.R.layout.simple_list_item_1, names);
//        setListAdapter(adapter);

    }

    public void onListItemClick(ListView lv, View v, int index, long id)
    {
          //This code would have set the map to the correct location of the item selected however due to
          //a problem with the SharedData array not being added to I had to comment it out whilst debugging.

//        MainActivity activity = (MainActivity)getActivity();
//        activity.mv.getController().setCenter(new GeoPoint(SharedData.places.get(i).getLat() , SharedData.places.get(i).getLat());
    }


}