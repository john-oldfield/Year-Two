package com.example.joldf_000.pointsofinterest;

/**
 * Created by joldf_000 on 12/04/2017.
 */
public class Place
{
    //Attributes of Place
    private String name;
    private String type;
    private String desc;
    private Double lat;
    private Double lon;

    //Constructor
    public  Place(String name, String type, String desc, Double lat, Double lon)
    {
        this.name = name;
        this.type = type;
        this.desc = desc;
        this.lat = lat;
        this.lon = lon;
    }

    //Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        this.lon = lon;
    }
}
