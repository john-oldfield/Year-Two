package com.example.joldf_000.pointsofinterest;

import java.util.ArrayList;

/**
 * Created by joldf_000 on 08/05/2017.
 */

public class SharedData
{
    //Static array so that it is accessible from every class
    public static ArrayList<Place> places;
}
